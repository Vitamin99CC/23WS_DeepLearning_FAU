

class BaseLayer:
    def __init__(self):
        self.weights = None
        self.input_tensor = None
        self.trainable = False
